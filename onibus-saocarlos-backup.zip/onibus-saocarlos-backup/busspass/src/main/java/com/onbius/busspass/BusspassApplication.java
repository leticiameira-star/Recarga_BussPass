package com.onbius.busspass;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BusspassApplication {

    public static void main(String[] args) {
        SpringApplication.run(BusspassApplication.class, args);
    }
}