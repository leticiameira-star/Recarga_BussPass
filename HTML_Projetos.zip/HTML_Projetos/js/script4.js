document.addEventListener("DOMContentLoaded", () => {

    const inputNovaSenha = document.getElementById("nova-senha");
    const inputConfirmarSenha = document.getElementById("confirmar-senha");
    const btnConfirmar = document.getElementById("btn-confirmar");

    const popup = document.getElementById("popup");
    const popupMessage = document.getElementById("popup-message");
    const popupClose = document.getElementById("popup-close");

    function mostrarPopup(mensagem, callback = null) {

        popupMessage.textContent = mensagem;
        popup.style.display = "flex";

        popupClose.onclick = () => {
            popup.style.display = "none";

            if (callback) {
                callback();
            }
        };
    }

    btnConfirmar.addEventListener("click", () => {

        const novaSenha = inputNovaSenha.value;
        const confirmarSenha = inputConfirmarSenha.value;

        if (!novaSenha || !confirmarSenha) {
            mostrarPopup("Por favor, preencha ambos os campos de senha.");
            return;
        }

        if (novaSenha.length < 6) {
            mostrarPopup("A nova senha deve ter pelo menos 6 caracteres.");
            return;
        }

        if (novaSenha !== confirmarSenha) {
            mostrarPopup("As senhas não coincidem. Digite com atenção.");
            return;
        }

        const usuarioSalvo = JSON.parse(
            localStorage.getItem("usuario")
        );

        if (usuarioSalvo) {

            usuarioSalvo.senha = novaSenha;

            localStorage.setItem(
                "usuario",
                JSON.stringify(usuarioSalvo)
            );

            mostrarPopup(
                "Sua senha foi redefinida com sucesso!",
                () => {
                    window.location.href = "login.html";
                }
            );

        } else {

            mostrarPopup(
                "Erro crítico: Nenhum usuário encontrado para alterar."
            );
        }
    });
});