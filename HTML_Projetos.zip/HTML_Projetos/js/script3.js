document.addEventListener("DOMContentLoaded", () => {

    const inputEmail = document.getElementById("email");
    const btnEnviarCodigo = document.getElementById("btn-enviar-codigo");
    const secaoCodigo = document.getElementById("secao-codigo");
    const inputCodigo = document.getElementById("codigo");
    const btnConfirmar = document.getElementById("btn-confirmar");

    const popup = document.getElementById("popup");
    const popupMessage = document.getElementById("popup-message");
    const popupClose = document.getElementById("popup-close");

    function mostrarPopup(mensagem, callback = null) {
        popupMessage.textContent = mensagem;
        popup.style.display = "flex";

        popupClose.onclick = () => {
            popup.style.display = "none";

            if (callback) {
                callback();
            }
        };
    }

    btnEnviarCodigo.addEventListener("click", () => {

        const emailDigitado = inputEmail.value.trim();
        const usuarioSalvo = JSON.parse(localStorage.getItem("usuario"));

        if (!emailDigitado) {
            mostrarPopup("Por favor, digite o seu e-mail.");
            return;
        }

        if (!usuarioSalvo || emailDigitado !== usuarioSalvo.email) {
            mostrarPopup("Este e-mail não corresponde a nenhum usuário cadastrado.");
            return;
        }

        mostrarPopup(
            `Um código de verificação foi enviado para: ${emailDigitado}`
        );

        secaoCodigo.classList.remove("hidden");

        inputEmail.disabled = true;
        btnEnviarCodigo.innerText = "Código Enviado";
        btnEnviarCodigo.disabled = true;
    });

    btnConfirmar.addEventListener("click", () => {

        const codigo = inputCodigo.value.trim();

        if (!codigo) {
            mostrarPopup("Por favor, insira o código recebido.");
            return;
        }

        if (codigo.length < 4) {
            mostrarPopup("Código inválido. Verifique o número digitado.");
            return;
        }

        mostrarPopup(
            "Código validado com sucesso! Vamos redefinir sua senha.",
            () => {
                window.location.href = "mudarsenha.html";
            }
        );
    });

    inputCodigo.addEventListener("input", (e) => {
        e.target.value = e.target.value.replace(/\D/g, "");
    });
});