document.addEventListener("DOMContentLoaded", () => {
    const valorCobrado = localStorage.getItem("valorCobrado") || "0,00";
    document.getElementById("valor-pix").innerText = valorCobrado;

    document.getElementById("btn-copiar").addEventListener("click", () => {
        const chavePix = document.getElementById("chave-pix");
        chavePix.select();
        document.execCommand("copy"); 
        alert("Código Pix copiado para a área de transferência!");
    });

    document.getElementById("btn-confirmar-pix").addEventListener("click", () => {
        alert("Pix recebido com sucesso! Seu pagamento foi confirmado.");
        localStorage.removeItem("valorCobrado"); 
        window.location.href = "paginainicial.html";
    });
});