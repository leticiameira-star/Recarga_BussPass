document.addEventListener("DOMContentLoaded", () => {
    const btnCadastrarManual = document.getElementById("btn-cadastrar");
    const btnLer = document.getElementById("btn-ler");

    const inputNome = document.getElementById("nome");
    const inputCPF = document.getElementById("cpf");
    const inputRG = document.getElementById("rg");
    const inputSubTipo = document.getElementById("subtipo");

    // Elementos do novo Modal
    const modal = document.getElementById("custom-modal");
    const modalMessage = document.getElementById("modal-message");
    const modalCloseBtn = document.getElementById("modal-close-btn");

    // Função auxiliar para abrir o pop-up customizado
    function mostrarModal(mensagem) {
        modalMessage.innerHTML = mensagem; // Permite quebras de linha ou negrito se necessário
        modal.classList.add("active");
    }

    // Função para fechar o pop-up
    modalCloseBtn.addEventListener("click", () => {
        modal.classList.remove("active");
    });

    // Opcional: Fecha o pop-up se o usuário clicar no fundo escuro fora da caixinha
    modal.addEventListener("click", (e) => {
        if (e.target === modal) {
            modal.classList.remove("active");
        }
    });

    // Máscara e validação do CPF
    inputCPF.addEventListener("input", (e) => {
        let value = e.target.value.replace(/\D/g, "");
        if (value.length > 11) value = value.slice(0, 11);

        value = value.replace(/(\d{3})(\d)/, "$1.$2");
        value = value.replace(/(\d{3})(\d)/, "$1.$2");
        value = value.replace(/(\d{3})(\d{1,2})$/, "$1-$2");
        
        e.target.value = value;
    });

    // Ação do botão Ler
    btnLer.addEventListener("click", () => {
        mostrarModal("Iniciando leitor...");
    });

    // Ação do botão Cadastrar
    btnCadastrarManual.addEventListener("click", () => {
        if (!inputNome.value || !inputCPF.value || !inputRG.value || !inputSubTipo.value) {
            mostrarModal("Por favor, preencha todos os campos antes de cadastrar.");
            return;
        }

        const dadosCarteirinha = {
            nome: inputNome.value,
            cpf: inputCPF.value,
            rg: inputRG.value,
            subTipo: inputSubTipo.value,
            dataCadastro: new Date().toLocaleDateString('pt-BR')
        };

        console.log("Dados salvos com sucesso:", dadosCarteirinha);
        mostrarModal(`Carteirinha de <strong>${dadosCarteirinha.nome}</strong> cadastrada com sucesso!`);

        limparFormulario();
    });

    function limparFormulario() {
        inputNome.value = "";
        inputCPF.value = "";
        inputRG.value = "";
        inputSubTipo.value = "";
    }
});