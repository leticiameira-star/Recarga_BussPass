document.addEventListener("DOMContentLoaded", () => {

    const inputValor = document.getElementById("valor-pagamento");
    const btnPix = document.getElementById("btn-pix");
    const btnCartao = document.getElementById("btn-cartao");

    const popup = document.getElementById("popup");
    const popupMessage = document.getElementById("popup-message");
    const popupClose = document.getElementById("popup-close");

    function mostrarPopup(mensagem, callback = null) {

        popupMessage.textContent = mensagem;
        popup.style.display = "flex";

        popupClose.onclick = () => {

            popup.style.display = "none";

            if (callback) {
                callback();
            }
        };
    }

    inputValor.addEventListener("input", (e) => {

        let value = e.target.value.replace(/\D/g, "");

        if (value === "") {
            e.target.value = "0,00";
            return;
        }

        value = (parseInt(value) / 100).toFixed(2);
        value = value.replace(".", ",");
        value = value.replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1.");

        e.target.value = value;
    });

    inputValor.addEventListener("focus", (e) => {
        if (e.target.value === "0,00") {
            e.target.value = "";
        }
    });

    inputValor.addEventListener("blur", (e) => {
        if (e.target.value === "") {
            e.target.value = "0,00";
        }
    });

    function salvarValorEIrPara(url) {

        const valor = inputValor.value;

        if (valor === "0,00" || valor === "") {

            mostrarPopup(
                "Por favor, digite um valor maior que zero para pagar."
            );

            return;
        }

        localStorage.setItem("valorCobrado", valor);

        window.location.href = url;
    }

    btnPix.addEventListener("click", () => {
        salvarValorEIrPara("pix.html");
    });

    btnCartao.addEventListener("click", () => {
        salvarValorEIrPara("cartao.html");
    });
});