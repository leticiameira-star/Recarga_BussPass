document.addEventListener("DOMContentLoaded", () => {

    const inputCPF = document.getElementById("login-cpf");
    const inputSenha = document.getElementById("login-senha");
    const btnLogin = document.getElementById("btn-login");

    const popup = document.getElementById("popup");
    const popupMessage = document.getElementById("popup-message");
    const popupClose = document.getElementById("popup-close");

    function mostrarPopup(mensagem, callback = null) {

        popupMessage.textContent = mensagem;
        popup.style.display = "flex";

        popupClose.onclick = () => {
            popup.style.display = "none";

            if (callback) {
                callback();
            }
        };
    }

    inputCPF.addEventListener("input", (e) => {
        let value = e.target.value.replace(/\D/g, "");

        if (value.length > 11) {
            value = value.slice(0, 11);
        }

        value = value.replace(/(\d{3})(\d)/, "$1.$2");
        value = value.replace(/(\d{3})(\d)/, "$1.$2");
        value = value.replace(/(\d{3})(\d{1,2})$/, "$1-$2");

        e.target.value = value;
    });

    btnLogin.addEventListener("click", () => {

        const cpfDigitado = inputCPF.value.trim();
        const senhaDigitada = inputSenha.value;

        if (!cpfDigitado || !senhaDigitada) {
            mostrarPopup("Por favor, preencha todos os campos.");
            return;
        }

        const usuarioSalvo = JSON.parse(
            localStorage.getItem("usuario")
        );

        if (!usuarioSalvo) {
            mostrarPopup(
                "Nenhum usuário cadastrado neste dispositivo! Crie uma conta primeiro."
            );
            return;
        }

        if (
            cpfDigitado === usuarioSalvo.cpf &&
            senhaDigitada === usuarioSalvo.senha
        ) {

            mostrarPopup(
                "Login efetuado com sucesso!",
                () => {
                    window.location.href = "paginainicial.html";
                }
            );

        } else {

            mostrarPopup(
                "CPF ou Senha incorretos."
            );
        }
    });
});