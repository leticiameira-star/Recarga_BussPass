document.addEventListener("DOMContentLoaded", () => {

    const inputCPF = document.getElementById("cpf");
    const inputEmail = document.getElementById("email");
    const inputSenha = document.getElementById("senha");
    const inputConfirmarSenha = document.getElementById("confirmar-senha");
    const btnCriarConta = document.getElementById("btn-criar-conta");

    const popup = document.getElementById("popup");
    const popupMessage = document.getElementById("popup-message");
    const popupClose = document.getElementById("popup-close");

    function mostrarPopup(mensagem, callback = null) {
        popupMessage.textContent = mensagem;
        popup.style.display = "flex";

        popupClose.onclick = () => {
            popup.style.display = "none";

            if (callback) {
                callback();
            }
        };
    }

    inputCPF.addEventListener("input", (e) => {
        let value = e.target.value.replace(/\D/g, "");

        if (value.length > 11) {
            value = value.slice(0, 11);
        }

        value = value.replace(/(\d{3})(\d)/, "$1.$2");
        value = value.replace(/(\d{3})(\d)/, "$1.$2");
        value = value.replace(/(\d{3})(\d{1,2})$/, "$1-$2");

        e.target.value = value;
    });

    btnCriarConta.addEventListener("click", () => {

        const cpf = inputCPF.value.trim();
        const email = inputEmail.value.trim();
        const senha = inputSenha.value;
        const confirmarSenha = inputConfirmarSenha.value;

        if (!cpf || !email || !senha || !confirmarSenha) {
            mostrarPopup("Por favor, preencha todos os campos.");
            return;
        }

        if (cpf.length < 14) {
            mostrarPopup("Por favor, insira um CPF válido.");
            return;
        }

        if (!email.includes("@") || !email.includes(".")) {
            mostrarPopup("Por favor, insira um e-mail válido.");
            return;
        }

        if (senha !== confirmarSenha) {
            mostrarPopup("As senhas não coincidem. Verifique e tente novamente.");
            return;
        }

        if (senha.length < 6) {
            mostrarPopup("A senha deve ter pelo menos 6 caracteres.");
            return;
        }

        const dadosUsuario = {
            cpf,
            email,
            senha
        };

        localStorage.setItem("usuario", JSON.stringify(dadosUsuario));

        mostrarPopup("Conta criada com sucesso!", () => {
            window.location.href = "login.html";
        });
    });
});