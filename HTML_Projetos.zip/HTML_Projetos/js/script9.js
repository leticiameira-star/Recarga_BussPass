document.addEventListener("DOMContentLoaded", () => {

    const valorCobrado = localStorage.getItem("valorCobrado") || "0,00";
    document.getElementById("valor-cartao").innerText = valorCobrado;

    const inputNumero = document.getElementById("num-cartao");
    const inputValidade = document.getElementById("validade");
    const inputCVV = document.getElementById("cvv");
    const inputNome = document.getElementById("nome-titular");
    const btnFinalizar = document.getElementById("btn-finalizar-cartao");

    const popup = document.getElementById("popup");
    const popupMessage = document.getElementById("popup-message");
    const popupClose = document.getElementById("popup-close");

    function mostrarPopup(mensagem, callback = null) {
        popupMessage.textContent = mensagem;
        popup.style.display = "flex";

        popupClose.onclick = () => {
            popup.style.display = "none";

            if (callback) {
                callback();
            }
        };
    }

    inputNumero.addEventListener("input", (e) => {
        let value = e.target.value.replace(/\D/g, "");

        value = value.replace(/(\d{4})(?=\d)/g, "$1 ");

        e.target.value = value;
    });

    inputValidade.addEventListener("input", (e) => {
        let value = e.target.value.replace(/\D/g, "");

        if (value.length > 2) {
            value = value.slice(0, 2) + "/" + value.slice(2, 4);
        }

        e.target.value = value;
    });

    inputCVV.addEventListener("input", (e) => {
        e.target.value = e.target.value.replace(/\D/g, "");
    });

    btnFinalizar.addEventListener("click", () => {

        if (
            !inputNumero.value ||
            !inputNome.value ||
            !inputValidade.value ||
            !inputCVV.value
        ) {
            mostrarPopup("Por favor, preencha todos os dados do cartão.");
            return;
        }

        if (
            inputNumero.value.length < 19 ||
            inputValidade.value.length < 5 ||
            inputCVV.value.length < 3
        ) {
            mostrarPopup("Dados do cartão incompletos. Verifique os campos.");
            return;
        }

        mostrarPopup(
            "Transação aprovada com sucesso! Obrigado.",
            () => {
                localStorage.removeItem("valorCobrado");
                window.location.href = "paginainicial.html";
            }
        );
    });
});